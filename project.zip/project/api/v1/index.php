<?php
    error_reporting(0);
    date_default_timezone_set("Asia/Jakarta");
    header("Content-Type: json/application");
    
    $conn = new mysqli("127.0.0.1", "root", "root", "vhacks");
    
    function delete_dir($dir) {
        if (is_dir($dir)) {
            $dir_handle = opendir($dir);
            if (!$dir_handle) {
                return false;
            }
            while (($file = readdir($dir_handle)) !== false) {
                if ($file != "." && $file != "..") {
                    if (is_dir($dir . "/" . $file)) {
                        delete_dir($dir . "/" . $file);
                    } else {
                        unlink($dir . "/" . $file);
                    }
                }
            }
            closedir($dir_handle);
            rmdir($dir);
            return true;
        }
        return false;
    }
    
    function getData($target) {
        global $conn;
        
        if (strpos($target, ".") !== false) {
            $result = $conn->query("SELECT * FROM data WHERE lhost='$target'");
            if ($result->num_rows > 0) {
                $data = [];
                while ($row = $result->fetch_assoc()) {
                    $data = $row;
                }
                $data["msg"] = "Data found";
                $data["cwd"] = "home/$target";
                return $data;
            } else {
                return ["msg" => "No data result!"];
            }
        } else {
            $result = $conn->query("SELECT * FROM data WHERE username='$target'");
            if ($result->num_rows > 0) {
                $data = [];
                while ($row = $result->fetch_assoc()) {
                    $data = $row;
                }
                $data["msg"] = "Data found";
                $data["cwd"] = "home/$target";
                return $data;
            } else {
                return ["msg" => "No data result!"];
            }
        }
    }
    
    function getPermsFile($file) {
        $perms = fileperms($file);
        
        if ($perms === false) {
            return "Could not retrieve permissions for $file.";
        } else {
            $owner_readable = ($perms & 0x0100) ? 'r' : '-';
            $owner_writable = ($perms & 0x0080) ? 'w' : '-';
            $owner_executable = ($perms & 0x0040) ? 'x' : '-';
            
            $group_readable = ($perms & 0x0020) ? 'r' : '-';
            $group_writable = ($perms & 0x0010) ? 'w' : '-';
            $group_executable = ($perms & 0x0008) ? 'x' : '-';
            
            $others_readable = ($perms & 0x0004) ? 'r' : '-';
            $others_writable = ($perms & 0x0002) ? 'w' : '-';
            $others_executable = ($perms & 0x0001) ? 'x' : '-';
            
            $permissions_string = sprintf("%s%s%s%s%s%s%s%s%s,",
                $owner_readable, $owner_writable, $owner_executable,
                $group_readable, $group_writable, $group_executable,
                $others_readable, $others_writable, $others_executable
            );
            
            return $permissions_string;
        }
    }
    
    function getGroupFile($file) {
        $groupId = filegroup($file);
        
        if ($groupId !== false) {
            $group = posix_getgrgid($groupId);
            if ($group) {
                return $group["name"];
            } else {
                return "Could not retrieve group information for ID: $groupId";
            }
        } else {
            return "Could not retrieve group ID for $file.";
        }
    }
    
    function getSizeFile($size) {
        
        if ($size >= 1073741824) {
            $size = number_format($size / 1073741824, 2) . 'G';
        } else if ($size >= 1048576) {
            $size = number_format($size / 1048576, 2) . 'M';
        } else if ($size >= 1024) {
            $size = number_format($size / 1024, 2) . 'K';
        } else if ($size > 1) {
            $size = $size;
        } else {
            $size = '0';
        }
        
        return $size;
    }
    
    function getLastModifyFile($file) {
        $lmt = filemtime($file);
        
        if ($lmt !== false) {
            return date("M d h:i", $lmt);
        } else {
            return "None";
        }
    }
    
    function getLs($dir) {
        global $conn;
        
        if (file_exists($dir)) {
            $dirs = scandir($dir);
            $dataDir = [];
            $total_bytes = 0;
            $getUser = explode("/", $dir);
            foreach ($dirs as $file) {
                if (is_dir($dir . "/" . $file)) {
                    $dataDir["directory"][] = [
                        getPermsFile("$dir/$file"),
                        count(glob("$dir/$file/*")),
                        $getUser[1],
                        getGroupFile("$dir/$file"),
                        getSizeFile(filesize("$dir/$file")),
                        getLastModifyFile("$dir/$file"),
                        "\033[1;34m$file\033[0m"
                    ];
                    $total_bytes = $total_bytes + filesize("$dir/$file");
                } else {
                    $dataDir["directory"][] = [
                        getPermsFile("$dir/$file"),
                        count(glob("$dir/$file")),
                        $getUser[1],
                        getGroupFile("$dir/$file"),
                        getSizeFile(filesize("$dir/$file")),
                        getLastModifyFile("$dir/$file"),
                        $file
                    ];
                    $total_bytes = $total_bytes + filesize("$dir/$file");
                }
            }
            $dataDir["total_bytes"] = getSizeFile($total_bytes);
            echo json_encode($dataDir, JSON_PRETTY_PRINT);
            exit;
        } else {
            echo json_encode(["msg" => "No such file or directory!"], JSON_PRETTY_PRINT);
            exit;
        }
    }
    
    switch ($_SERVER["REQUEST_METHOD"]) {
        case "GET":
            if (empty($_GET["key"])) {
                echo json_encode(["msg" => "Please enter the key!"], JSON_PRETTY_PRINT);
                exit;
            }
            
            $key = $_GET["key"];
            
            if ($key == "getdata") {
                if (empty($_GET["target"])) {
                    echo json_encode(["msg" => "Please enter the target!"], JSON_PRETTY_PRINT);
                    exit;
                }
                
                $target = $_GET["target"];
                
                echo json_encode(getData($target), JSON_PRETTY_PRINT);
                exit;
            } else if ($key == "getdirectory") {
                if (empty($_GET["paths"])) {
                    echo json_encode(["msg" => "Please enter the paths!"], JSON_PRETTY_PRINT);
                    exit;
                }
                
                $paths = $_GET["paths"];
                
                getLs($paths);
            }
            
        case "POST":
            if (empty($_POST["key"])) {
                echo json_encode(["msg" => "Please enter the key!"], JSON_PRETTY_PRINT);
                exit;
            }
            
            $key = $_POST["key"];
            
            if ($key == "createdata") {
                if (empty($_POST["username"])) {
                    echo json_encode(["msg" => "Please enter the username!"], JSON_PRETTY_PRINT);
                    exit;
                }
                if (empty($_POST["password"])) {
                    echo json_encode(["msg" => "Please enter the password!"], JSON_PRETTY_PRINT);
                    exit;
                }
                if (empty($_POST["lhost"])) {
                    echo json_encode(["msg" => "Please enter the lhost!"], JSON_PRETTY_PRINT);
                    exit;
                }
                
                $username = $_POST["username"];
                $password = $_POST["password"];
                $lhost = $_POST["lhost"];
                
                $result = $conn->query("SELECT * FROM data WHERE username='$username'");
                if ($result->num_rows < 1) {
                    if ($conn->query("INSERT INTO data (username, password, lhost) VALUES ('$username','$password','$lhost')")) {
                        if (is_dir("data")) {
                            mkdir("data/$username");
                            $firewallFile = fopen("home/$username/firewall.log", "w");
                            fwrite($firewallFile, date("[d-m-Y h:i:s]") . " Admin has preparing your device");
                            fclose($firewallFile);
                        } else {
                            if (mkdir("data")) {
                                mkdir("data/$username");
                                $firewallFile = fopen("home/$username/firewall.log", "w");
                                fwrite($firewallFile, date("[d-m-Y h:i:s]") . " Admin has preparing your device");
                                fclose($firewallFile);
                            }
                        }
                        echo json_encode(["msg" => "Create data successfully"], JSON_PRETTY_PRINT);
                        exit;
                    } else {
                        echo json_encode(["msg" => "Failed to create data!"], JSON_PRETTY_PRINT);
                        exit;
                    }
                } else {
                    echo json_encode(["msg" => "Username already in use!"], JSON_PRETTY_PRINT);
                    exit;
                }
            }

        case "DELETE":
            if (empty($_GET["key"])) {
                echo json_encode(["msg" => "Please enter the key!"], JSON_PRETTY_PRINT);
                exit;
            }

            $key = $_GET["key"];

            if ($key == "deletedata") {
                if (empty($_GET["target"])) {
                    echo json_encode(["msg" => "Please enter the target!"], JSON_PRETTY_PRINT);
                    exit;
                }

                $target = $_GET["target"];

                if (strpos($_GET["target"], ".") !== false) {
                    $result = $conn->query("SELECT * FROM data WHERE lhost='$target'");
                    if ($result->num_rows > 0) {
                        $data = getData($target);
                        if ($conn->query("DELETE FROM data WHERE lhost='$target'")) {
                            if (delete_dir("home/" . $data["username"])) {
                                echo json_encode(["msg" => "Data successfully deleted"], JSON_PRETTY_PRINT);
                                exit;
                            } else {
                                echo json_encode(["msg" => "Failed to delete data!"], JSON_PRETTY_PRINT);
                                exit;
                            }
                        } else {
                            echo json_encode(["msg" => "Failed to delete data!"], JSON_PRETTY_PRINT);
                            exit;
                        }
                    } else {
                        echo json_encode(["msg" => "No data result!"], JSON_PRETTY_PRINT);
                        exit;
                    }
                } else {
                    $result = $conn->query("SELECT * FROM data WHERE username='$target'");
                    if ($result->num_rows > 0) {
                        if ($conn->query("DELETE FROM data WHERE username='$target'")) {
                            if (delete_dir("home/" . $target)) {
                                echo json_encode(["msg" => "Data successfully deleted"], JSON_PRETTY_PRINT);
                                exit;
                            } else {
                                echo json_encode(["msg" => "Failed to delete data!"], JSON_PRETTY_PRINT);
                                exit;
                            }
                        } else {
                            echo json_encode(["msg" => "Failed to delete data!"], JSON_PRETTY_PRINT);
                            exit;
                        }
                    } else {
                        echo json_encode(["msg" => "No data result!"], JSON_PRETTY_PRINT);
                        exit;
                    }
                }
            }

    }
?>