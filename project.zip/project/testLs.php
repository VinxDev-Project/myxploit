<?php
	error_reporting(0);
	date_default_timezone_set("Asia/Jakarta");
	header("Content-Type: application/json");
	
	function getPermsFile($file) {
	    $perms = fileperms($file);
	    
        if ($perms === false) {
            return "Could not retrieve permissions for $file.";
        } else {
            $owner_readable = ($perms & 0x0100) ? 'r' : '-';
            $owner_writable = ($perms & 0x0080) ? 'w' : '-';
            $owner_executable = ($perms & 0x0040) ? 'x' : '-';
            
            $group_readable = ($perms & 0x0020) ? 'r' : '-';
            $group_writable = ($perms & 0x0010) ? 'w' : '-';
            $group_executable = ($perms & 0x0008) ? 'x' : '-';
            
            $others_readable = ($perms & 0x0004) ? 'r' : '-';
            $others_writable = ($perms & 0x0002) ? 'w' : '-';
            $others_executable = ($perms & 0x0001) ? 'x' : '-';
            
            $permissions_string = sprintf("%s%s%s%s%s%s%s%s%s,",
                $owner_readable, $owner_writable, $owner_executable,
                $group_readable, $group_writable, $group_executable,
                $others_readable, $others_writable, $others_executable
            );
            
            return $permissions_string;
        }
    }
	
	function getLs($dir) {
        global $conn;
        
        if (file_exists($dir)) {
            $dirs = scandir($dir);
            $dataDir = [];
            foreach ($dirs as $file) {
                if (is_dir($dir . "/" . $file)) {
                    $dataDir[] = [
                        "permissions" => getPermsFile($dir . "/" . $file),
                        "name_file" => $file
                    ];
                } else {
                    $dataDir[] = [
                        "permissions" => getPermsFile($dir . "/" . $file),
                        "name_file" => $file
                    ];
                }
            }
            echo json_encode($dataDir, JSON_PRETTY_PRINT);
        } else {
            echo json_encode(["msg" => "Directory not found!"], JSON_PRETTY_PRINT);
        }
    }
	
	switch ($_SERVER["REQUEST_METHOD"]) {
	    case "GET":
	        if (empty($_GET["target"])) {
	            echo json_encode(["msg" => "Please enter the target!"], JSON_PRETTY_PRINT);
	            exit;
	        }
	        getLs("api/v1/data/" . $_GET["target"]);
	}
?>
