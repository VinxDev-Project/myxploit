import requests, json, os, faker, datetime, time, pwinput

url = "http://127.0.0.1:8081/api/v1"

#CREATE DATA
def createData(username, password):
    print("\nOutput\n")
    print(
        json.dumps(
            requests.post(url, data={"key": "createdata", "username": username, "password": password, "lhost": faker.Faker().ipv4()}).json()
        , indent=4)
    )

def getData(target):
    print("\nOutput\n")
    print(
        json.dumps(
            requests.get(f"{url}?key=getdata&target={target}").json()
        , indent=4)
    )

def deleteData(target):
    print("\nOutput\n")
    print(
        json.dumps(
            requests.delete(f"{url}?key=deletedata&target={target}").json()
        , indent=4)
    )
    
def convert_vhc(vhc, coin):
    if len(str(coin)) == 1:
        return f"{vhc}.{'0'*7}{coin}"
    elif len(str(coin)) == 2:
        return f"{vhc}.{'0'*6}{coin}"
    elif len(str(coin)) == 3:
        return f"{vhc}.{'0'*5}{coin}"
    elif len(str(coin)) == 4:
        return f"{vhc}.{'0'*4}{coin}"
    elif len(str(coin)) == 5:
        return f"{vhc}.{'0'*3}{coin}"
    elif len(str(coin)) == 6:
        return f"{vhc}.{'0'*2}{coin}"
    elif len(str(coin)) == 7:
        return f"{vhc}.{'0'*1}{coin}"
    elif len(str(coin)) == 8:
        return f"{vhc}.{coin}"

menus = [
    "Create data",
    "Get Data",
    "Delete data"
]

while True:
    time.sleep(3)
    os.system("clear")
    print(convert_vhc(1, 99999999))
    try:
        for n in range(len(menus)):
            print(f"[{n}] {menus[n]}")
        prompt = int(input("\nEnter the menu: "))
        print()
        if "Create" in menus[prompt]:
            print("CREATE DATA\n")
            p1 = input("Enter the username: ")
            p2 = pwinput.pwinput(prompt="Enter the password: ", mask="*")
            createData(p1, p2)
        elif "Get" in menus[prompt]:
            print("GET DATA\n")
            p1 = input("Enter the target: ")
            getData(p1)
        elif "Delete" in menus[prompt]:
            print("DELETE DATA\n")
            p1 = input("Enter the target: ")
            deleteData(p1)
        else:
            print("The menu you entered is under development!")
    except IndexError:
        print("Menu not available")
    except ValueError:
        print("\nPlease enter the menu correctly")
    except KeyboardInterrupt:
        os.system("clear")
        print("Bye bye ^_^")
        break